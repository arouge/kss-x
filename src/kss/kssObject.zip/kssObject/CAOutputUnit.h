//
//  CAOutputUnit.h
//  testAUInput
//
//  Created by James Chen on 8/12/04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#include <AudioUnit/AudioUnit.h>

@interface CAOutputUnit : NSObject {
    AudioUnit m_OutputUnit;
    id m_Delegate;
}
- (void)start;
- (void)stop;
- (id)delegate;
- (void)setDelegate:(id)delegate;
- (AudioUnit)outputUnit;
- (BOOL)isRunning;
- (AudioStreamBasicDescription)deviceFormat;
- (AudioStreamBasicDescription)desiredFormat;
- (void)setDesiredFormat:(AudioStreamBasicDescription)desiredFormat;
- (void)matchFormat;
@end
@interface NSObject(CAOutputUnitDelegate)
- (void)outputUnit:(CAOutputUnit *)outputUnit requestFrames:(UInt32)frames data:(AudioBufferList *)data flags:(AudioUnitRenderActionFlags *)flags timeStamp:(const AudioTimeStamp *)timeStamp;
@end