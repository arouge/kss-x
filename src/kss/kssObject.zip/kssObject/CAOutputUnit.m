//
//  CAOutputUnit.m
//  testAUInput
//
//  Created by James Chen on 8/12/04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import "CAOutputUnit.h"


@implementation CAOutputUnit
static OSStatus CAOutputUnitRenderProc(
                        void *inRefCon,
                        AudioUnitRenderActionFlags *ioActionFlags,
                        const AudioTimeStamp *inTimeStamp,
                        UInt32 inBusNumber,
                        UInt32 inNumberFrames,
                        AudioBufferList *ioData)
{
    NSAutoreleasePool *ap = [[NSAutoreleasePool alloc] init];
    CAOutputUnit *output = (CAOutputUnit *)inRefCon;
    OSStatus theErr = noErr;
    if ([[output delegate] respondsToSelector:@selector(outputUnit:requestFrames:data:flags:timeStamp:)]) {
        [[output delegate] outputUnit:output requestFrames:inNumberFrames data:ioData flags:ioActionFlags timeStamp:inTimeStamp];
    }
    [ap release];
    return theErr;
}
- (void)dealloc
{
    if (m_OutputUnit) {
        CloseComponent(m_OutputUnit);
    }
    [super dealloc];
}
- (void)matchFormat
{
    [self setDesiredFormat:[self deviceFormat]];
}
- (AudioUnit)outputUnit
{
    if (m_OutputUnit == nil) {
        Component comp;
        ComponentDescription desc;
        
        desc.componentType = kAudioUnitType_Output;
        desc.componentSubType = kAudioUnitSubType_HALOutput;
        desc.componentManufacturer = kAudioUnitManufacturer_Apple;
        desc.componentFlags = 0;
        desc.componentFlagsMask = 0;
        comp = FindNextComponent(NULL, &desc);
        if (comp == NULL) {
            goto bail;
        }
        // Open AUHAL AudioOutputUnit
        OSStatus theErr = noErr;
        theErr = OpenAComponent(comp, &m_OutputUnit);
        if (theErr != noErr) {
            goto bail;
        }
	UInt32 enableIO, hasIO;
	UInt32 propSize;
        hasIO = 0;
        propSize = sizeof(hasIO);
        AudioUnitGetProperty(m_OutputUnit,
                kAudioOutputUnitProperty_HasIO,
                kAudioUnitScope_Output,
                0, // output element
                &hasIO,
                &propSize);

        if (hasIO) {
            enableIO = 0;
            theErr = AudioUnitSetProperty(m_OutputUnit,
                    kAudioOutputUnitProperty_EnableIO,
                    kAudioUnitScope_Input,
                    1,
                    &enableIO,
                    sizeof(enableIO));
            if (theErr != noErr) {
                goto bail;
            }
            enableIO = 1;
            theErr = AudioUnitSetProperty(m_OutputUnit,
                    kAudioOutputUnitProperty_EnableIO,
                    kAudioUnitScope_Output,
                    0,   //output element
                    &enableIO,
                    sizeof(enableIO));
            if (theErr != noErr) {
                goto bail;
            }
            // select the default output device for AudioOutputUnit
            propSize = sizeof(AudioDeviceID);
            AudioDeviceID outputDevice;
            theErr = AudioHardwareGetProperty(
                        kAudioHardwarePropertyDefaultOutputDevice, 
                        &propSize, 
                        &outputDevice);
            if (theErr != noErr) {
                goto bail;
            }
            theErr = AudioUnitSetProperty(
                        m_OutputUnit, 
                        kAudioOutputUnitProperty_CurrentDevice, 
                        kAudioUnitScope_Global, 
                        0, 
                        &outputDevice, 
                        sizeof(outputDevice));
            if (theErr != noErr) {
                goto bail;
            }
            AURenderCallbackStruct render;
            
            render.inputProc = CAOutputUnitRenderProc;
            render.inputProcRefCon = self;
            theErr = AudioUnitSetProperty(
                            m_OutputUnit, 
                            kAudioUnitProperty_SetRenderCallback, 
                            kAudioUnitScope_Input,
                            0,
                            &render, 
                            sizeof(render));
            if (theErr != noErr) {
                goto bail;
            }
            
            //[self matchFormat];
            
            theErr = AudioUnitInitialize(m_OutputUnit);
            if (theErr != noErr) {
                goto bail;
            }
            goto success;
        }
bail:
        if (m_OutputUnit) {
            CloseComponent(m_OutputUnit);
            m_OutputUnit = nil;
        }
    
    }
success:
    return m_OutputUnit;
}
- (void)start
{
    if ([self outputUnit] && ![self isRunning])
        AudioOutputUnitStart([self outputUnit]);
}
- (void)stop
{
    if ([self outputUnit] && [self isRunning])
        AudioOutputUnitStop([self outputUnit]);
}

- (id)delegate
{
    return m_Delegate;
}
- (void)setDelegate:(id)delegate
{
    m_Delegate = delegate;
}
- (BOOL)isRunning
{
    UInt32 isRunning = 0;
    if (m_OutputUnit) {
        UInt32 propertySize = sizeof(UInt32);
        
        AudioUnitGetProperty(
                        [self outputUnit], 
                        kAudioOutputUnitProperty_IsRunning, 
                        kAudioUnitScope_Global, 
                        0, 
                        &isRunning, 
                        &propertySize);
    }
    return (isRunning != 0);
}
- (AudioStreamBasicDescription)deviceFormat
{
    AudioStreamBasicDescription deviceFormat;
    UInt32 size = sizeof(AudioStreamBasicDescription);

     //Get the input device format
    AudioUnitGetProperty([self outputUnit],
                           kAudioUnitProperty_StreamFormat,
                           kAudioUnitScope_Output,
                           0,
                           &deviceFormat,
                           &size);
    return deviceFormat;
}
- (AudioStreamBasicDescription)desiredFormat;
{
    AudioStreamBasicDescription desiredFormat;
    UInt32 size = sizeof(AudioStreamBasicDescription);

     //Get the input device format
    AudioUnitGetProperty([self outputUnit],
                           kAudioUnitProperty_StreamFormat,
                           kAudioUnitScope_Input,
                           0,
                           &desiredFormat,
                           &size);
    return desiredFormat;
}
- (void)setDesiredFormat:(AudioStreamBasicDescription)desiredFormat
{
    ComponentResult result = AudioUnitSetProperty([self outputUnit],
                            kAudioUnitProperty_StreamFormat,
                            kAudioUnitScope_Input,
                            0,
                            &desiredFormat,
                            sizeof(AudioStreamBasicDescription));
    //NSLog(@"%D", result);
}
@end
