#import "kssObject.h"

static id _sharedInstance; 

@implementation kssObject

+(id)sharedInstance { 
    if (!_sharedInstance) 
        _sharedInstance = [[[self class] alloc] init]; 
    
    return _sharedInstance; 
} 

- (id) init { 
    if (_sharedInstance) { 
        [self dealloc]; 
        self = [_sharedInstance retain]; 
    } else { 
        self = [super init]; 
        if (self != nil) { 
            //initialisation "normale" 
        } 
        _sharedInstance = self; 
    }
//	m_startTime = [NSDate init];
    
			
//	m_fileOpen = [NSNumber numberWithInt:0];
    return self; 
} 

-(NSNumber *)sccMask
{
	return m_sccMask;
}

-(NSNumber *)psgMask
{
	return m_psgMask;
}


-(void)setPsgMask:(NSNumber *)psgMask
{
	[m_psgMask release];
	m_psgMask = [psgMask copy];
}

-(void)setSccMask:(NSNumber *)sccMask
{
	[m_sccMask release];
	m_sccMask = [sccMask copy];
}

-(void)setOplMask:(NSNumber *)oplMask
{
	[m_oplMask release];
	m_oplMask = [oplMask copy];
}

-(void)setopllMask:(NSNumber *)opllMask
{
	[m_opllMask release];
	m_opllMask = [opllMask copy];
}

- (NSNumber *)fileOpen
{
	return m_fileOpen;
}

- (void)setFileOpen:(NSNumber *)status
{
	m_fileOpen = [status copy];
}

- (NSString *)kssFile
{
	return m_kssFile;
}

- (BOOL)setKssFile:(NSString *)kssFile
{
	char fileNameC[256];
	//Ressource Consuming
	
	//KSSPLAY_set_device_quality(kssplay,EDSC_SCC,YES);
	//KSSPLAY_set_device_lpf(kssplay,EDSC_SCC,22000);
	
	if(![kssFile isEqual:m_kssFile])
	{
	
		(void)strncpy(fileNameC,[kssFile cString], sizeof(fileNameC));
		[m_kssFile release];
		m_kssFile = [kssFile copy];

		if((kss=KSS_load_file(fileNameC))==NULL)
		{	
			[m_kssFile release];
			m_kssFile = [kssFile copy];
			return(0);
		}
		else
		{
			[m_kssFile release];
			m_kssFile = [kssFile copy];
			return(1);
			[self updateKss:1];
		}
	}
	else 
	{
		if([m_fileOpen intValue])return(1);
		else return(0);
	}
}

-(NSNumber *)size
{
	return [NSNumber numberWithInt:kss->init_adr];
}

-(NSNumber *)masterVolume
{
	return m_masterVolume;
}

-(BOOL)isRunning
{
	return [m_OutputUnit isRunning];
}

-(void)changeMasterVolume:(NSNumber *)masterVolume
{
	NSNotificationCenter *nc;

	m_masterVolume = [masterVolume copy];
	nc = [NSNotificationCenter defaultCenter];
	[nc postNotificationName:@"volumeChanged" object:nil];
}

-(void)changeSccVolume:(NSNumber *)sccVolume
{
	NSNotificationCenter *nc;

	m_sccVolume = [sccVolume copy];
	nc = [NSNotificationCenter defaultCenter];
	[nc postNotificationName:@"volumeChanged" object:nil];
}

-(void)changeOplVolume:(NSNumber *)oplVolume
{
	NSNotificationCenter *nc;

	m_oplVolume = [oplVolume copy];
	nc = [NSNotificationCenter defaultCenter];
	[nc postNotificationName:@"volumeChanged" object:nil];
}

-(void)changeOpllVolume:(NSNumber *)opllVolume
{
	NSNotificationCenter *nc;

	m_opllVolume = [opllVolume copy];
	nc = [NSNotificationCenter defaultCenter];
	[nc postNotificationName:@"volumeChanged" object:nil];
}

-(void)changePsgVolume:(NSNumber *)psgVolume
{
	NSNotificationCenter *nc;
	m_psgVolume = [psgVolume copy];

	nc = [NSNotificationCenter defaultCenter];
	[nc postNotificationName:@"volumeChanged" object:nil];
}

-(NSNumber *)psgVolume
{
 return m_psgVolume;
}

-(NSNumber *)sccVolume
{
 return m_sccVolume;
}

-(NSNumber *)oplVolume
{
 return m_oplVolume;
}

-(NSNumber *)opllVolume
{
 return m_opllVolume;
}

- (NSNumber *)frameRate
{
	return m_frameRate;
}

- (void)setVdpSpeed:(NSNumber *)vdpSpeed
{
	[m_vdpSpeed release];
	m_vdpSpeed = [vdpSpeed copy];
	[self updateKss:0];

}

- (void)setFrameRate:(NSNumber *)frameRate
{
	[self pause];
	[m_frameRate release];
	m_frameRate = [frameRate copy];
	myAudioProperty.mSampleRate = [m_frameRate intValue];
	[m_OutputUnit setDesiredFormat:myAudioProperty];

	[self updateKss:1];
	[self play];
}

- (NSNumber *)songNumber
{
	return m_songNumber;
}

- (void)setSongNumber:(NSNumber *)songNumber
{
	[m_songNumber release];
	m_songNumber = [songNumber copy];
	[self updateKss:0];
}

- (NSNumber *)playTime
{
	return m_playTime;
}

- (void)setPlayTime:(NSNumber *)playTime
{
	[m_playTime release];
	m_playTime = [playTime copy];
}


- (NSNumber *)bufferSize
{
	return m_bufferSize;
}

- (void)setBufferSize:(NSNumber *)bufferSize
{
	[m_bufferSize release];
	m_bufferSize = [bufferSize copy];
}

-(void)setOpllPan:(NSNumber *)channel: (NSNumber *)value
{
	int i=[channel intValue];
	
	opllPan[i] = [value intValue];	
}

- (void)updateKss:(BOOL)total // Create KSS stuff
{
	NSNotificationCenter *nc;
	int nch = 2;

	if(total)
	{
		if([m_OutputUnit isRunning])
		{
			[self togglePause];
			
			KSSPLAY_delete(kssplay);
			kssplay = KSSPLAY_new([m_frameRate intValue], nch, 16) ;
			kssplay->opll_stereo = 1;
			[self togglePause];
		}
		else
		{
			KSSPLAY_delete(kssplay);
			kssplay = KSSPLAY_new([m_frameRate intValue], nch, 16) ; 
			kssplay->opll_stereo = 1;

		}
	}
		
	if([m_fileOpen intValue])
	{
		// INIT KSSPLAY 
		KSSPLAY_set_data(kssplay, kss) ;
		kssplay->vsync_freq = [m_vdpSpeed intValue];
		KSSPLAY_reset(kssplay, [m_songNumber intValue], 0) ;
	}

	m_playTime = [NSNumber numberWithInt:0];
	[self setPlayTime:@"0"]; 
	framePlayed = 0;

	nc = [NSNotificationCenter defaultCenter];
	[nc postNotificationName:@"SongPositionChanged" object:nil];
	[nc postNotificationName:@"songFileChanged" object:nil];
	[nc postNotificationName:@"songRestarted" object:nil];
}

-(NSDate *)startTime
{
	return m_startTime;
}

- (void)createAudio // Create and start Audio
{
	shortMax = 1.0f / ((float) 0x7fff);
	m_moreToDo = true;
	
	m_OutputUnit = [[CAOutputUnit alloc] init];
	
	myAudioProperty.mChannelsPerFrame = 2;
    myAudioProperty.mBitsPerChannel = 32;
    myAudioProperty.mBytesPerFrame = 4;
    myAudioProperty.mBytesPerPacket = 4;
	#ifdef __BIG_ENDIAN__
		myAudioProperty.mFormatFlags = kLinearPCMFormatFlagIsFloat | kAudioFormatFlagIsBigEndian | kAudioFormatFlagIsPacked | kAudioFormatFlagIsNonInterleaved;
	#else
       myAudioProperty.mFormatFlags = kLinearPCMFormatFlagIsFloat | kLinearPCMFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked | kAudioFormatFlagIsNonInterleaved;
	#endif
	
	 myAudioProperty.mFormatID = kAudioFormatLinearPCM;
    myAudioProperty.mFramesPerPacket = 1;
    myAudioProperty.mSampleRate = [m_frameRate intValue];
	
	[m_OutputUnit setDesiredFormat:myAudioProperty];
    [m_OutputUnit setDelegate:self];
	
	[m_OutputUnit start];
	opllPan[0] = 3; opllPan[1] = 3;
	opllPan[2] = 3; opllPan[3] = 3;
	opllPan[4] = 3; opllPan[5] = 3;
	opllPan[6] = 3; opllPan[7] = 3;
	opllPan[8] = 3; opllPan[9] = 3;
	opllPan[10] = 3; opllPan[11] = 3;
	opllPan[12] = 3; opllPan[13] = 3;
	intPsgPan = 3;
	intSccPan = 3;
	intOplPan = 3;
	intOpllPan = 3;
	
	//		opll_pan0=3; opll_pan1=3; opll_pan2=3; opll_pan3=3; opll_pan4=3; opll_pan5=3; opll_pan6=3; opll_pan7=3;
	//		opll_pan8=3; opll_pan9=3; opll_pan10=3; opll_pan11=3; opll_pan12=3; opll_pan13=3;
	m_fileOpen = [NSNumber numberWithInt:0];
}
-(void)play
{
	[m_OutputUnit start];
}

-(void)pause
{
	[m_OutputUnit stop];
}

-(void)togglePause
{
	switch([m_OutputUnit isRunning])
	{
		case true: [m_OutputUnit stop];
		break;
		case false:[m_OutputUnit start];
		break;
	}
}

- (void)resetSong
{
	int i=0;
	for(i=0;i<=MAX_RATE*2;i++)
	{
		shortBuffer[0][i]=0;
		shortBuffer[1][i]=0;
	}
}

-(void)setMoreToDo:(NSNumber *)value
{
	m_moreToDo = [value intValue];
}

-(NSNumber *)moreToDo
{
	return [NSNumber numberWithInt:m_moreToDo];
}

-(void)setFadeOutTime:(int)fadeTime
{
	fadeOutTime = fadeTime;
}

- (void)setSongTime:(int)songTime
{
	m_songTime = songTime;
}
- (id)generateBuffer
{	
    NSAutoreleasePool * localPool = [[NSAutoreleasePool alloc] init];
	threadLock = [[NSConditionLock alloc] initWithCondition: NO_DATA];

	NSNotificationCenter *nc;
	nc = [NSNotificationCenter defaultCenter];

	while(m_moreToDo){
		KSSPLAY_set_device_volume(kssplay,EDSC_PSG,[m_psgVolume intValue]);
		KSSPLAY_set_device_volume(kssplay,EDSC_SCC,[m_sccVolume intValue]);
		KSSPLAY_set_device_volume(kssplay,EDSC_OPL,[m_oplVolume intValue]);
		KSSPLAY_set_device_volume(kssplay,EDSC_OPLL,[m_opllVolume intValue]);
		KSSPLAY_set_master_volume(kssplay,[m_masterVolume intValue]);
		KSSPLAY_set_channel_mask(kssplay,EDSC_PSG,[m_psgMask intValue]);
		KSSPLAY_set_channel_mask(kssplay,EDSC_SCC,[m_sccMask intValue]);
		KSSPLAY_set_channel_mask(kssplay,EDSC_OPL,[m_oplMask intValue]);
		KSSPLAY_set_channel_mask(kssplay,EDSC_OPLL,[m_opllMask intValue]);

		KSSPLAY_set_device_pan(kssplay,EDSC_PSG,2);
		KSSPLAY_set_device_pan(kssplay,EDSC_SCC,3);
		KSSPLAY_set_device_pan(kssplay,EDSC_OPL,5);
		KSSPLAY_set_device_pan(kssplay,EDSC_OPLL,9);
		
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,0,opllPan[0]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,1,opllPan[1]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,2,opllPan[2]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,3,opllPan[3]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,4,opllPan[4]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,5,opllPan[5]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,6,opllPan[6]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,7,opllPan[7]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,8,opllPan[8]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,9,opllPan[9]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,10,opllPan[10]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,11,opllPan[11]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,12,opllPan[12]);
		KSSPLAY_set_channel_pan(kssplay,EDSC_OPLL,13,opllPan[13]);


		KSSPLAY_calc(kssplay, shortBuffer[bufferToCalc], [[self bufferSize] intValue]) ;
		
		framePlayed = framePlayed + [[self bufferSize] intValue];
		
		if(framePlayed >= [[self frameRate] intValue])
		{
			framePlayed = framePlayed - [[self frameRate] intValue];
			m_playTime = [NSNumber numberWithInt:[[self playTime] intValue] +1];

			[nc postNotificationName:@"SongPositionChanged" object:nil];
		}
		[threadLock lockWhenCondition:HAS_DATA];
	}
	
	[localPool release];
	return 0;

}
- (void)outputUnit:(CAOutputUnit *)outputUnit requestFrames:(UInt32)frames data:(AudioBufferList *)data flags:(AudioUnitRenderActionFlags *)flags timeStamp:(const AudioTimeStamp *)timeStamp;
{
    NSAutoreleasePool * localPool = [[NSAutoreleasePool alloc] init];

    int i = 0 ,j = 0;
    float *bufferLeft, *bufferRight;
	
	bufferLeft = (float *)(data->mBuffers[0].mData);
	bufferRight = (float *)(data->mBuffers[1].mData);

	for (j = 0; j < data->mBuffers[i].mDataByteSize/4; j ++)
	{
		bufferRight[j] = ((float)shortBuffer[bufferToPlay][position]) * shortMax;
		bufferLeft[j] = ((float)shortBuffer[bufferToPlay][position+1]) * shortMax;	
				
		if(position>=(([[self bufferSize] intValue]*2)-2))		{
			
			position = 0;
			
			switch(bufferToPlay)
			{
				case 0:
				{
					bufferToPlay = 1;bufferToCalc = 0;}
					break ;
				case 1 :
				{
					bufferToPlay = 0;bufferToCalc = 1;}
					break ;
				}
				[threadLock unlockWithCondition:HAS_DATA];
			}
		position++;position++;
	}
	[localPool release];

} 
-(NSNumber *)getPsgVolume
{
   return m_psgVolume;
}

-(NSNumber *)getPsgMask
{
   return m_psgMask;
}

-(NSNumber *)getSccVolume
{
   return m_sccVolume;
}

-(NSNumber *)getSccMask
{
   return m_sccMask;
}

-(NSNumber *)getOplVolume
{
   return m_oplVolume;
}

-(NSNumber *)getOplMask
{
   return m_oplMask;
}

-(NSNumber *)getOpllVolume
{
   return m_opllVolume;
}

-(NSNumber *)getOpllMask
{
   return m_opllMask;
}

-(NSNumber *)getOpllPan:(NSNumber *)channelNumber
{
   int i;
   i = [channelNumber intValue];
   
   return [NSNumber numberWithInt:opllPan[i]];
}

-(NSNumber *)getMasterVolume
{
	return m_masterVolume;
}

-(void)setPsgPan:(NSNumber *)psgPan
{
   intPsgPan = [psgPan intValue];
}

-(void)setSCCPan:(NSNumber *)sccPan
{
   intSccPan = [sccPan intValue];
}

-(void)setOplPan:(NSNumber *)oplPan
{
   intOplPan = [oplPan intValue];
}

-(void)setOpllPan:(NSNumber *)opllPan
{
   intOpllPan = [opllPan intValue];
}

@end